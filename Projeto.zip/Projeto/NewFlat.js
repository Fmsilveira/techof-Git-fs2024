const flats = JSON.parse(localStorage.getItem('NewFlat')) || [];

function addFlat() {
  const flatName = document.getElementById('street').value;
  flats.push(flatName);
  localStorage.setItem('flats', JSON.stringify(flats));
  renderList();
}

function renderList() {
  const flatList = document.getElementById('flats');
  flatList.innerHTML = '';
  flats.forEach(flatName => {
    const newFlat = document.createElement('li');
    newFlat.textContent = flatName;
    flatList.appendChild(newFlat);
  });
}

document.addEventListener('onload', renderList());