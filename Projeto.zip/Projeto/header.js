function renderHeader() {
  const header = document.getElementById('header');
  const user = localStorage.getItem('user');
  const isUserLoggedIn = !!user;
  header.innerHTML = `
    <a href="./home.html">Home</a>
      <a href="./Flats.html">Flats</a>
      <a href="">Profile</a>
      <a href="./register.html">Register</a>

      <img src="./logo.png"></img>

      ${isUserLoggedIn ? `<p>Hello, ${user}</p> ` : `<a href=./login.html">Login</a>`}
`
}
document.addEventListener('onload', renderHeader())