function loginData () {
    let password
    let email;

    password=document.getElementById("password").value;
    email=document.getElementById("email").value;

    const user_login = JSON.parse(localStorage.getItem("users"))
    if (user_login.some((i)=>{
        return i.email ==email && i.password ==password
    })) {
        alert ("Successfull Login");
        const user_login = user_data.filter((i) => {
            return i.email == email && i.password == password
        })[0]
        localStorage.setItem("firstname", user_login.firstname);
        localStorage.setItem("lastname", user_login.lastname);
        localStorage.setItem("email", user_login.email);
    }
}